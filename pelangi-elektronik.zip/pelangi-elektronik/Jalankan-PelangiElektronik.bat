@echo off
setlocal EnableExtensions
title Pelangi Elektronik - Jalankan Aplikasi
cd /d "%~dp0"

echo ==================================================
echo   Pelangi Elektronik - menyiapkan dan menjalankan aplikasi
echo ==================================================
echo.

where php >nul 2>nul
if errorlevel 1 ( echo [GAGAL] PHP tidak ditemukan. Pasang PHP 8.4 atau lebih baru dan tambahkan ke PATH. & goto :akhir )
where composer >nul 2>nul
if errorlevel 1 ( echo [GAGAL] Composer tidak ditemukan. Pasang dari https://getcomposer.org & goto :akhir )
where npm >nul 2>nul
if errorlevel 1 ( echo [GAGAL] Node.js/npm tidak ditemukan. Pasang Node.js 20 atau lebih baru. & goto :akhir )

if not exist ".env" (
    echo [1/6] Membuat berkas .env dari .env.example ...
    copy /y ".env.example" ".env" >nul
    set BARU=1
)

if not exist "vendor\autoload.php" (
    echo [2/6] Memasang dependensi PHP - bisa beberapa menit ...
    call composer install --no-interaction
    if errorlevel 1 ( echo [GAGAL] composer install gagal. Lihat PANDUAN-INSTALASI.md bagian Pemecahan Masalah. & goto :akhir )
) else ( echo [2/6] Dependensi PHP sudah ada. )

findstr /b /c:"APP_KEY=base64" ".env" >nul 2>nul
if errorlevel 1 (
    echo [3/6] Membuat APP_KEY ...
    call php artisan key:generate --force
)

echo [4/6] Menyiapkan database - membuat database, migrasi, dan data demo ...
call php artisan pelangi:setup
if errorlevel 1 ( echo [GAGAL] Database belum siap. Bawaan memakai SQLite (tanpa XAMPP). Jika Anda memilih MySQL, nyalakan MySQL dan periksa DB_* di .env. & goto :akhir )

call php artisan storage:link >nul 2>nul

if not exist "public\build\manifest.json" (
    echo [5/6] Memasang dan membangun tampilan - butuh internet pada pemasangan pertama ...
    call npm install
    if errorlevel 1 ( echo [GAGAL] npm install gagal. Periksa koneksi internet. & goto :akhir )
    call npm run build
    if errorlevel 1 ( echo [GAGAL] npm run build gagal. & goto :akhir )
) else ( echo [5/6] Tampilan sudah dibangun. )

echo [6/6] Menjalankan server di http://127.0.0.1:8000
echo.
echo   Akun demo - kata sandi semua: password
echo     Owner     : owner@pelangi.test
echo     Staff     : staff@pelangi.test
echo     Pelanggan : pelanggan@pelangi.test
echo.
echo   Tekan Ctrl+C untuk menghentikan server.
echo.
start "" "http://127.0.0.1:8000"
call php artisan serve --host=127.0.0.1 --port=8000

:akhir
echo.
pause
endlocal
