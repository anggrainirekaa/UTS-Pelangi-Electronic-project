<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('barangs', function (Blueprint $table) {
            $table->index('name');
            $table->index('stock');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->index('name');
        });

        Schema::table('suppliers', function (Blueprint $table) {
            $table->index('name');
        });

        Schema::table('stock_ins', function (Blueprint $table) {
            $table->index('date');
        });

        Schema::table('stock_outs', function (Blueprint $table) {
            $table->index('date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('barangs', function (Blueprint $table) {
            $table->dropIndex(['name']);
            $table->dropIndex(['stock']);
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->dropIndex(['name']);
        });

        Schema::table('suppliers', function (Blueprint $table) {
            $table->dropIndex(['name']);
        });

        Schema::table('stock_ins', function (Blueprint $table) {
            $table->dropIndex(['date']);
        });

        Schema::table('stock_outs', function (Blueprint $table) {
            $table->dropIndex(['date']);
        });
    }
};